﻿namespace SoccerClub.API
{
    public interface IApiHelper
    {
        string GetRecentUpdates();
    }
}
