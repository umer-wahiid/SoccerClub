﻿namespace SoccerClub.Models
{
    public class Statistics
    {
    }
}
