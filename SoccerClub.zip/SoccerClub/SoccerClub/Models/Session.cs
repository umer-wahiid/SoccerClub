﻿namespace SoccerClub.Models
{
	public static class Session
	{

		public static int UserId { get; set; }
		public static string IsAdmin { get; set; } = "NO";

    }
}
